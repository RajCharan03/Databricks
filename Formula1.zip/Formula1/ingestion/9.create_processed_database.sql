-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_processed
LOCATION '/mnt/formularacedl1/processed'

-- COMMAND ----------

DESC DATABASE EXTENDED f1_processed

-- COMMAND ----------

