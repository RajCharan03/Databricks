-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_presentation
LOCATION '/mnt/formularacedl1/presentation'

-- COMMAND ----------

